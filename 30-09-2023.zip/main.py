# number = int(input("Digite um número"))

# number2 = int(input("Digite outro número"))

# print(number * number2)

#CONCATENAR#
# cumprimento = input('Digite o seu nome: ')
# print('Olá, tudo bem, '+cumprimento)

# age = int(input('Digite sua Idade ->'))
# name = input('Digite seu nome ->')
# compras = float(input('Digite suas compras do mês ->'))
# compras02 = float(input('Digite suas compras do mês anterior ->'))
# print('Nome:', name, '', 'Idade:', age, '', 'somas das compras:', compras + compras02)

                                         #AULA 02
#Exercicio01

# number = int(input("Digite o número: "))
# quadrado = "Este número ao quadrado é igual a: "
# resultado = print(quadrado, number * 2)

#Exercício02

# nome1 = input("Qual o seu primeiro nome: ")
# nome2 = input("Qual seu sobrenome:  ")
# nome3 = print("Seu nome completo é: ", nome1, '' + nome2)

#Exercicio03

# numero1 = int(input('Digite o número: '))
# numero2 = int(input('Digite o segundo número: '))
# result = print(numero1, numero2)

#Exercício04

# palavra = "Python"
# numero = input("Digite o número: ")
# print("Resultado :", palavra + numero)

              #Format

# nome = input('Digite aqui seu nome - ')
# idade = input('Digite aqui sua idade - ')
# endereco = input('Digite aqui seu endereço - ')
# cargo = input('Digite aqui seu cargo - ')
# # print('meu nome é ', nome, ', minha idade é ', idade, ', meu endereço é ', endereco, ', meu cargo é ', cargo )

# print(f'Meu nome é {nome}, Minha idade é {idade}, Meu endereço é {endereco}, Meu cargo é {cargo}')

#Exercicio05
# frase = 'sua comida preferida é '
# frase_usuario = input('Digite aqui sua comida preferida: ')
# print(f{frase} ,{frase_usuario})

#Exercicio06
# hora = '11'
# minuto = '51'
# segundo = '30'
# print(f'O horário é {hora}:{minuto}:{segundo}')

#Exercicio07
# telefone = '985074739'
# ddd = '(11)'
# print(ddd + telefone)

#Exercicio08 
# ingrediente1 = 'Massa'
# ingrediente2 = '4 ovos'
# ingrediente3 = 'Leite'
# ingrediente4 = 'Fermento'
# ingrediente5 = 'Chocolate'
# print(f'Segue os ingredientes para uma receita de bolo: \n\n {ingrediente1};\n {ingrediente2};\n {ingrediente3};\n {ingrediente4};\n {ingrediente5}')

#Exercicio09
# adjetivo1 = input('Digite seu primeiro adjetivo: -> ')
# adjetivo2 = input('Digite seu segundo adjetivo -> ')
# adjetivo3 = input('Digite seu terceiro adjetivo: -> ')
# print(f'Esses são meus 3 adjetivos:  {adjetivo1}, {adjetivo2} e {adjetivo3}')

#Condicionais
# numero = float(input('Digite o número: '))
# if numero == 10:
#   print(f'O número é {numero}')
# else:
#   print(f'Opa é {numero}')

# senha_digitada = input('Digite uma senha: ')
# nome = input('Digite seu nome: ')
# senha = '1234'
# if senha == senha_digitada and nome == 'Camila':
#  print('Acesse')
# else:
#  print (f'Não pode acessar, porque digitou {senha_digitada} ou {nome} incorretamente')

#Atividade3 1
# idade = int(input('Digite sua idade: '))
# if idade <=45:
#   print('menor que 45 anos')
# else:
#   print('maior que 18 anos')

# Atv2
# idade = int(input('Qual sua idade?  '))
# if idade >=18:
#  print('Entrada permitida')
# else:
#  print('Entrada não permitida')

#Atv3 Sistemas de notas
# media = 7
# calabreso = float(input('Digite a nota do Calabreso -> '))
# if calabreso >=media:
#  print('\n Calabreso Aprovado\n')
# else:
#  print('\n Calabreso Reprovado\n')
  
# mussarelo = float(input('Digite a nota do Mussarelo -> '))
# if mussarelo >=media:
#  print('\n Mussarelo Aprovado\n')
# else:
#  print('\n Mussarelo Reprovado\n')
  
# cervejo = float(input('Digite a nota do Cervejo -> '))
# if cervejo >=media:
#  print('\n Cervejo Aprovado\n')
# else:
#  print('\n Cervejo Reprovado\n')
  
# if calabreso and mussarelo and cervejo >=media:
#  print('\nMaioria dos Alunos Aprovados\n')
# else:
#  print('\nMaioria dos Alunos Reprovados\n')

